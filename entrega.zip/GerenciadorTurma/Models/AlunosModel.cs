﻿using System.Collections.Generic;

namespace GerenciadorTurma.Models
{
    public class AlunosModel
    {
        public string Filtro { get; set; }
        public List<Aluno> Alunos { get; set; }
    }
}
