﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GerenciadorTurma.Models.Alunos
{
    public class IndexModel
    {

    }
}
